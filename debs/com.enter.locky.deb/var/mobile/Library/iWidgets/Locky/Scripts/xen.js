
//--------------------------- XENINFO ---------------------------
function mainUpdate(type){ 
	if(type === "weather"){
		checkWeather();
	}else if (type === "battery"){
		updateBattery();	  	
	}else if(type == "reminders"){
		checkRem();
    }else if(type == "events"){
		checkEvent();
    }
}

//------------------------- REMINDERS FUNCTIONS ---------------------------
function checkRem(){
	if(reminders.length > 0){
		document.getElementById('_rem').innerHTML = '';
	}else{
		document.getElementById('_rem').innerHTML = '';
	}
    for (var i = 0; i < reminders.length; i++) {
        document.getElementById('_rem').innerHTML += reminders[i].title + " - " + reminders[i].dueDate + "</br>";
    }
}

//------------------------- EVENTS FUNCTIONS ---------------------------
function checkEvent(){
	if(events.length > 0){
		document.getElementById('_eve').innerHTML = 'Calendar';
	}else{
		document.getElementById('_eve').innerHTML = '';
	}
    for (var i = 0; i < events.length; i++) {
        //document.getElementById('_eve').innerHTML += events[i].title + " - " + events[i].date + "</br>";
		var _box = document.createElement('div'),
            _time = document.createElement('span'),
            _title = document.createElement('span'),
			_line = document.createElement('div');
			
		if(events[i].isAllDay){
			_time.innerHTML = 'all day';
		}else{
			_time.innerHTML = transformTime(events[i].startTimeTimestamp) + ' - ' + transformTime(events[i].endTimeTimestamp) + '<br>' + events[i].date;
		}
		_time.style.cssText = "color:" + C1 + ";\
							  font-size:12px;\
							  font-family: 'semi';";
		_box.appendChild(_time);
		
		_title.innerHTML = ' ' + events[i].title;
		_title.style.cssText = "color:" + events[i].associatedCalendarHexColor + ";\
							   font-size:12px;";
		_box.appendChild(_title);
		
		_line.style.cssText = "border:0.5px solid " + C1 + ";\
							   opacity:0.3;\
							   width: 45vw;";
		_box.appendChild(_line);
		
		document.getElementById('eveCont').appendChild(_box);
    }
}

function transformTime(unix){
	var date = new Date(unix*1000);
	var hours = date.getHours();
	var minutes = "0" + date.getMinutes();
	
	var formattedTime = hours + ':' + minutes.substr(-2);
	
	return formattedTime;
}

//------------------------- WEATHER FUNCTIONS ---------------------------
function checkWeather(){
	document.getElementById('_condition').innerHTML = weather.condition;
	document.getElementById('_temp').innerHTML = weather.temperature + "º";
	
}


//------------------------- BATTERY FUNCTIONS ---------------------------
var startAnim = false;
function updateBattery(){
	if(batteryCharging === 1 && ch === 1){
		if(startAnim === false){
			startAnim = true;
			document.getElementById('particles-js').style.display = 'block';
			document.getElementById('particles-js').style.opacity = 1;
		}
	}else{
		startAnim = false;
		document.getElementById('particles-js').style.opacity = 0;
		document.getElementById('particles-js').style.display = 'none';
	}
}
