
window.addEventListener("load", function() { 
   document.body.style.width='100%';
   document.body.style.height='100%';
}, false);



function init(){
	document.getElementById('particles-js').style.display = 'none';
	updateClock();
	setInterval("updateClock();", 1000);
	checkSettings();
}

function checkSettings(){
	document.documentElement.style.setProperty('--primary', C1);
	document.documentElement.style.setProperty('--secondary', C2);
	document.documentElement.style.setProperty('--third', C3);
	
	if(we === 0){
		document.getElementById('weatCont').style.display = 'none';
	}
	
	if(dt === 0){
		document.getElementById('dateCont').style.display = 'none';
	}
	
	document.getElementById('_condition').style.fontSize = F1 + 'px';
	document.getElementById('_date').style.fontSize = F1 + 'px';
	document.getElementById('_time').style.fontSize = F1 + 'px';
	
	document.getElementById('_temp').style.fontSize = F2 + 'px';
	document.getElementById('_month').style.fontSize = F2 + 'px';
	document.getElementById('_day').style.fontSize = F2 + 'px';
	
	if(cr === 0){
		document.getElementById('remCont').style.display = 'none';
		document.getElementById('eveCont').style.display = 'none';
	}
	
	if(cf === 1){
		document.getElementById('remCont').classList.remove("reminder");
		document.getElementById('remCont').classList.add("event");
		document.getElementById('remCont').style.opacity = 0;
		document.getElementById('eveCont').style.opacity = 1;
	}
	
	if(ch === 0){
		document.getElementById('partCont').style.display = 'none';
	}
}


//------------------------- EV REM SHOW FUNCTIONS ---------------------------
function showER(){
	if(document.getElementById('remCont').classList.contains("reminder")){
		document.getElementById('remCont').classList.remove("reminder");
		document.getElementById('remCont').classList.add("event");
		
		TweenMax.to(document.getElementById('remCont'), 0.5, {alpha:0});
		TweenMax.to(document.getElementById('eveCont'), 0.5, {alpha:1});
		return;
	}
	
	if(document.getElementById('remCont').classList.contains("event")){
		document.getElementById('remCont').classList.remove("event");
		document.getElementById('remCont').classList.add("reminder");
		
		TweenMax.to(document.getElementById('remCont'), 0.5, {alpha:1});
		TweenMax.to(document.getElementById('eveCont'), 0.5, {alpha:0});
		return;
	}
}


//------------------------- TIME FUNCTIONS ---------------------------
function updateClock() { 
	var currentTime = new Date();
	var currentHours = currentTime.getHours();
	var currentMinutes = currentTime.getMinutes();
	var currentMinutes1 = currentTime.getMinutes();
	var currentMinutesunit = currentTime.getMinutes();
	var currentSeconds = currentTime.getSeconds() < 10 ? '0' + currentTime.getSeconds() : currentTime.getSeconds();
	var currentDate = currentTime.getDate() < 10 ? '0' + currentTime.getDate() : currentTime.getDate();
	var currentYear = currentTime.getFullYear();
	//var Time24 = 1;
	
	if(Time24 === 1){
		Clock = "24h";
	}else{
		Clock = "12h";
	}
	
	if (Clock === "24h"){
		currentHours = ( currentHours < 10 ? "0" : "" ) + currentHours;
		currentMinutes1= ( currentMinutes1< 10 ? "0" : "" ) + currentMinutes1;
	}
	if (Clock === "12h"){
		currentHours = ( currentHours > 12 ) ? currentHours - 12 : currentHours;
		currentHours = ( currentHours == 0 ) ? 12 : currentHours;
		currentMinutes1= ( currentMinutes1< 10 ? "0" : "" ) + currentMinutes1;
	}
	
	document.getElementById("_month").innerHTML = shortmonths[currentTime.getMonth()]
	document.getElementById("_date").innerHTML = currentDate + ", " + currentYear;
	document.getElementById("_day").innerHTML = shortdays[currentTime.getDay()]
	document.getElementById("_time").innerHTML = currentHours + " : " + currentMinutes1;
		
}
